Udleveret skelet bestod af følgende:

Under "Move.cs" var der navnet på "move" og en mulighed for at få adgang til dette.
Under "Pokemon.cs" Var der enum Elements, level, baseAttack, baseDefence, hp, maxHp og element og en mulighed for at få adgang til disse.
Constructor med disse data. Oprettet metoder (Attack, CalculateElementalEffect, ApplyDamage og Restore) uden indhold.
Under "Program.cs" List roster, while(true) og nogle Console.Write for at skrive tekst. int move =-1; int damage =-1;
if som tjekker at Pokemon spiller og modstander ikke er null. if som tjekker at spilleren og modstanderen har mere en 0 hp. 

Resten er noget som jeg selv har tilføjet.
